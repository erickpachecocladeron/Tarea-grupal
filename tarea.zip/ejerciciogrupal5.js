// 5. ((8 > 2) | | (932 < 23) ) && 4 == 2
// Bosquejo
// ENT: ((8 > 2) | | (932 < 23) ) && 4 == 2(calcular)
// PRO: ((8>2) | | (932<23))&&4===2 
// SAL: mostrar el mensaje
let resultado=((8 > 2) || (932 < 23) ) && 4 == 2
console.log(resultado)