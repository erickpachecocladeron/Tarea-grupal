// 2. (5 + 3 * 2) + 9 > 3 * 5 * 14 % 3
// Bosquejo
// ENT: 5(leer); 3(leer); 2(leer); 9(leer); 14(leer)
// PRO: (5 + 3 * 2) + 9 > 3 * 5 * 14 % 3
// SAL: mostrar el mensaje
let resultado=(5 + 3 * 2) + 9 > 3 * 5 * 14 % 3
console.log(resultado)