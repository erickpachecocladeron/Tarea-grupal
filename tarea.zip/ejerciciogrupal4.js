// 4. 260 / 12 + 54 % 3 – 85 % 7
// Bosquejo
// ENT: 260 / 12 + 54 % 3 – 85 % 7(calcular)
// PRO: 260 / 12 + 54 % 3 – 85 % 7
// SAL: mostrar el mensaje
let resultado=260 / 12 + 54 % 3 - 85 % 7
console.log(resultado)