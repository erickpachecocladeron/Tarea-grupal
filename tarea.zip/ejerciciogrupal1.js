// 1. Para a=8 y b=5, encuentra el valor de v = 2 * b + a div 2 + 4 * b mod a.
// Bosquejo
// ENT: a(leer); b(leer); v(calcular)
// PRO: v=2*5+8/2+4*5%8
// SAL: mostrar el mensaje
let a=8
let b=5
let v=2*5+8/2+4*5%8
console.log(v)