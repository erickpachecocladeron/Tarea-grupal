// 3. 2 *(4 – 10 + 8)/2* 36 *(1/2)
// Bosquejo
// ENT: 2 *(4 – 10 + 8)/2* 36 *(1/2)(calcular)
// PRO: 2 *(4 – 10 + 8)/2* 36 *(1/2)
// SAL: mostrar el mensaje
let resultado=2 *(4 - 10 + 8)/2* 36 *(1/2)
console.log(resultado)